Rails.application.routes.draw do
  get 'index/loadFile'
  get 'index/index'
  get 'index/loadAgrupation'
  get 'index/loadClient'
  get 'index/liquidar'
  get 'index/liquidar_fonografico'
  get 'index/diccionario'
  get 'index/loadSong'


  match '/executeLoadAgrupation' => 'index#executeLoadAgrupation', via: :post
  match '/executeLoadClient' => 'index#executeLoadClient', via: :post
  match '/executeLoadFile' => 'index#executeLoadFile', via: :post
  match '/executeLiquidar' => 'index#executeLiquidar', via: :post
  match '/executeLiquidarFonografico' => 'index#executeLiquidarFonografico', via: :post
  match '/executeLoadDic' => 'index#executeLoadDic', via: :post

  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
  root 'index#index'
end
