class LoadFileController < ApplicationController
  def loadFile
  end
end
