
class IndexController < ApplicationController
  skip_before_action :verify_authenticity_token  
  def index
  end

  def executeLoadAgrupation
  	agrupacion = Agrupacion.create(Id_grupo: params[:id_agrupacion],Nombre_grupo: params[:nombre_agrupacion], Id_genero: params[:id_genero], Id_tipo_banda: params[:id_tipo_agrupacion])
    integrantes = params[:integrantes]

    integrantes.each do |id|
      grupo_contratante = GrupoContratante.create(Id_grupo: params[:id_agrupacion], Id_contratante: id)
    end
  end

  def executeLoadClient
  	cliente = Contratante.create(Id_contratante: params[:id_cliente],Nombre_contratante: params[:nombre_cliente],Correo_contratante: params[:email], Direccion_contratante: params[:direccion],Ciudad_contratante: params[:ciudad])
    tipos_contratante = params[:tipo_usuario]

    tipos_contratante.each do |id|
      cliente_tipo_contratante = ContratanteTipoContratante.create(id_Contratante: params[:id_cliente], id_Tipo_contratante: id)
    end
  end

  def executeLoadFile
  	id_socio = params[:socio]
  	data_doc = params[:document]
    formato = FormatoDocumento.find(id_socio)
    data_no_subida = []
    for i in 0..(formato.fila_inicial-1)
      data_doc.delete(0)
    end
    nombre_reporte = params[:nombre] + " ( " + params[:fecha] + " ) "
    reporte = Reporte.create(Id_reporte: nil,Doc_reporte:params[:document_blob], Estado_pago: 0, Fecha: params[:fecha], Id_socio: id_socio, Id_tipo_aparicion: params[:tipo_aparicion], Nombre_reporte: nombre_reporte,Comentario: params[:comentario])
    reporte = Reporte.last
    data_doc.each do |row|
      if(params[:tipo_aparicion].to_i === 1)
        id_obra = Obra.find_by(nombre_obra: row[formato.nombre_obra])
        if(id_obra == nil)
          wordDic = Diccionario.find_by(nombre_obra: row[formato.nombre_obra])
          if(wordDic != nil)
            id_obra = Obra.find_by(nombre_obra: wordDic)
          end
        end
      else
        id_obra = ObraAutoral.find_by(nombre_obra: row[formato.nombre_obra])
        if(id_obra == nil)
          wordDic = Diccionario.find_by(nombre_obra: row[formato.nombre_obra])
          if(wordDic != nil)
            id_obra = ObraAutoral.find_by(nombre_obra: wordDic)
          end
        end
      end

      if(id_obra != nil)
        id_obra = id_obra.Id_obra
        precio = row[formato.precio]
        if(formato.tipo_aparicion == nil)
          tipo_aparicion = nil
        else
          tipo_aparicion = row[formato.tipo_aparicion]
        end
        if(formato.duracion == nil)
          duracion = nil
        else
          duracion = row[formato.duracion]
        end
        if(formato.cantidad == nil)
          cantidad = nil
        else
          cantidad = row[formato.cantidad]
        end
        if(formato.fecha == nil)
          fecha = nil
        else
          fecha = row[formato.fecha]
        end
        if(formato.territorio == nil)
          territorio = nil
        else
          territorio = row[formato.territorio]
        end
        if(formato.medio_aparicion == nil)
          medio_aparicion = nil
        else
          medio_aparicion = row[formato.medio_aparicion]
        end
        Time.zone = 'Bogota'
        aparicion = Aparicion.create(Id_obra: id_obra, Id_reporte: reporte.Id_reporte, Id_socio: id_socio, Duracion: duracion, Cantidad: cantidad, Precio: precio, Fecha: params[:fecha], Territorio: territorio, Id_medio_aparicion: medio_aparicion)
      else
        data_no_subida.push(row[formato.nombre_obra]);
      end

    end
    respond_to do |format|

      format.html # show.html.erb
      format.json { render json: data_no_subida }
    end
  end

  def executeLoadDic
    entrada = params[:entrada]
    salida = params[:salida]
    Diccionario.create(Entrada: entrada, Salida: salida)
  end
  def executeLiquidar
    
    workbook = RubyXL::Workbook.new
    worksheet = workbook.add_worksheet('liquidacion')
      headers = ['id obra', 'obra', 'id autor','nombre autor', 'grupo interprete', 'territorio', 'porcentaje_autor', 'porcentaje_editora', 'valor autor', 'valor editora', 'valor reportado', 'catalogo']
      col = 0

      headers.each do |hd|
        worksheet.add_cell(0,col,hd)
        col += 1
      end

      row = 1
      params[:reportes].each do |id_reporte|
        Aparicion.where("Id_reporte = ?", id_reporte).each do |aparicion|
          id_obra = aparicion.Id_obra
          price = aparicion.Precio
          obra = ObraAutoral.where("Id_obra=? AND Catalogo=?", id_obra, params[:catalogo])[0]
          if(obra != nil)
            if(aparicion.Territorio == 'Colombia' || aparicion.Territorio == nil)
              porcentaje_autor = obra.Porcentaje_colombia
              porcentaje_editora = obra.Porcentaje_editora_colombia
            else
              porcentaje_autor = obra.Porcentaje_internacional
              porcentaje_editora = obra.Porcentaje_editora_internacional
              
            end
            if(Contratante.find_by(Id_contratante: obra.Autor_id) != nil)
                nombre_contratante = Contratante.find_by(Id_contratante: obra.Autor_id).Nombre_contratante
                
            else
              nombre_contratante = 'Autor no reconocido'
            end
                price_editora = porcentaje_editora*price
                price_editora = price_editora - (price_editora*params[:descuento].to_f/100.0)
                price_autor = porcentaje_autor*price
                price_autor = price_autor - (price_autor*params[:descuento].to_f/100.0)
                
                data = [id_obra, obra.Nombre_obra,obra.Autor_id ,nombre_contratante, Agrupacion.find(obra.Grupo).Nombre_grupo, aparicion.Territorio,porcentaje_autor,porcentaje_editora, price_autor, price_editora, price, obra.Catalogo  ]
                

                col = 0
                data.each do |cl|
                  worksheet.add_cell(row,col,cl)
                  col += 1
                end
            row += 1
          end
          
        end
      end

      workbook.write("liquidacion.xlsx")
    end

    def executeLiquidarFonografico
    
      workbook = RubyXL::Workbook.new
      worksheet = workbook.add_worksheet('liquidacion')
        headers = ['id obra', 'obra', 'grupo interprete', 'territorio', 'porcentaje interprete', 'porcentaje editora', 'porcentaje sub editora', 'valor interprete', 'valor editora', 'valor sub editora', 'valor reportado', 'editora']
        col = 0
  
        headers.each do |hd|
          worksheet.add_cell(0,col,hd)
          col += 1
        end
  
        row = 1
        params[:reportes].each do |id_reporte|
          Aparicion.where("Id_reporte = ?", id_reporte).each do |aparicion|
            id_obra = aparicion.Id_obra
            price = aparicion.Precio
            obra = Obra.where("Id_obra=? AND Editora=?", id_obra, params[:catalogo])[0]
            if(obra != nil)
              porcentaje_interprete = obra.Porcentaje_interprete_fon
              porcentaje_editora = obra.Porcentaje_editora_fon
              porcentaje_subeditora = obra.Porcentaje_subeditor_fon
              valor_subeditor = price*porcentaje_subeditora;
              valor_subeditor -= valor_subeditor*params[:descuento].to_f/100.0
              valor_tot = price - valor_subeditor
              valor_editora = valor_tot*porcentaje_editora
              valor_editora -= valor_editora*params[:descuento].to_f/100.0
              valor_interprete = valor_tot*porcentaje_interprete
              valor_interprete -= valor_interprete*params[:descuento].to_f/100.0
              data = [id_obra, obra.Nombre_obra, Agrupacion.find(obra.Id_grupo).Nombre_grupo, aparicion.Territorio,porcentaje_interprete, porcentaje_editora,porcentaje_subeditora, valor_interprete, valor_editora,valor_subeditor, price, obra.Editora  ]
    
              col = 0
              data.each do |cl|
                worksheet.add_cell(row,col,cl)
                col += 1
              end
              row += 1
            end
            
          end
        end
  
        workbook.write("liquidacion.xlsx")
      end
end
