class Obra < ApplicationRecord
	self.table_name="Obra"


end