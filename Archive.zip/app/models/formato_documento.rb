class FormatoDocumento < ApplicationRecord
	self.table_name = "formato_documento"
	self.primary_key = "id_socio"
end