class ContratanteTipoContratante < ApplicationRecord
	self.table_name = "Contratante_Tipo_contratante"
end