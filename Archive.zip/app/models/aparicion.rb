class Aparicion < ApplicationRecord
	self.table_name="Aparicion"

end