class GeneroMusical < ApplicationRecord
	self.table_name = "Genero_musical"

end
