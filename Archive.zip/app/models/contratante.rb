class Contratante < ApplicationRecord
	self.table_name = "Contratante"
end