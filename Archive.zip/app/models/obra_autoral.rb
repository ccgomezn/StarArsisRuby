class ObraAutoral < ApplicationRecord
	self.table_name = "Obra_autoral"
end