class Diccionario < ApplicationRecord
	self.table_name = "Diccionario"
end