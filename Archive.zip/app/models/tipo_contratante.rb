class TipoContratante < ApplicationRecord
	self.table_name = "Tipo_contratante"

end