class GrupoContratante < ApplicationRecord
	self.table_name = "Grupo_contratante"

end