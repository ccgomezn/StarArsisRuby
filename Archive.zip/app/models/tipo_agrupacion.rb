class TipoAgrupacion < ApplicationRecord
	self.table_name = "TipoBanda"


end