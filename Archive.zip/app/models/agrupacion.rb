class Agrupacion < ApplicationRecord
	self.table_name = "Grupo"

end
