class Organizacion < ApplicationRecord
	self.table_name = "Socio"

end