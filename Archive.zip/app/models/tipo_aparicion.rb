class TipoAparicion < ApplicationRecord
	self.table_name = "Tipo_aparicion"
end