class Reporte < ApplicationRecord
	self.table_name = "Reporte"
    self.primary_key = 'Id_reporte'

end